create view BIGPOLICIES as
  SELECT Policy_No, Type, Premium_Amt
FROM Policies
WHERE PREMIUM_AMT >= 50
ORDER BY Premium_Amt, Start_Date
/


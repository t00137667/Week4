create view TOTAL_CLAIMS as
  SELECT Policy_No, COUNT(*)AS NUM, SUM(Amount) AS Claims
FROM PAYMENTS
GROUP BY Policy_No
/


create view POLICY_HOLDERS as
  SELECT Policy_No, Type, Surname, Forename, Premium_Amt
FROM Policies P JOIN HOLDERS H ON P.Holder_ID = H.Holder_ID
ORDER BY P.TYPE, Surname, Forename
/

